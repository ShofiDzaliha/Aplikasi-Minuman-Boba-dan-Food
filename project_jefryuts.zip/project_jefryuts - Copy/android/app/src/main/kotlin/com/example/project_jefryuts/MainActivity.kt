package com.example.project_jefryuts

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
